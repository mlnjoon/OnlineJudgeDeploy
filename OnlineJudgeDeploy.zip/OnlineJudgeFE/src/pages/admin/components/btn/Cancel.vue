<template>
  <el-button plain type="primary">Cancel</el-button>
</template>
<script>
  export default{
    name: 'Cancel'
  }
</script>
